#ifndef __MODEL_JSON_H__
#define __MODEL_JSON_H__

const char recognition_model_string_json[] = {"{\"NumModels\":1,\"ModelIndexes\":{\"0\":\"ECG_FIRST_RANK_0\"},\"ModelDescriptions\":[{\"Name\":\"ECG_FIRST_RANK_0\",\"ClassMaps\":{\"1\":\"Kevin_ECG\",\"2\":\"Libra_ECG\",\"3\":\"Ruby_ECG\",\"4\":\"Unknown\",\"0\":\"Unknown\"},\"ModelType\":\"DecisionTreeEnsemble\",\"FeatureFunctions\":[\"Skewness\",\"Minimum\",\"Median\",\"LinearRegressionStats\",\"Maximum\",\"Variance\",\"25thPercentile\",\"AbsoluteSum\",\"InterquartileRange\"]}]}"};

int32_t recognition_model_string_json_len = sizeof(recognition_model_string_json);

#endif /* __MODEL_JSON_H__ */
